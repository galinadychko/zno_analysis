library(testthat)
library(cdata)

test_check("cdata")
