library(testthat)
library(rquery)

test_check("rquery")
