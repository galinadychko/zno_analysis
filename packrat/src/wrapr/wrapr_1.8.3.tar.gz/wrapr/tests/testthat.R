library(testthat)
library(wrapr)

test_check("wrapr")
